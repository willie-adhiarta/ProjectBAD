/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package id.binus.project.bad;

/**
 *
 * @author joice
 */
import java.sql.*;

public class DatabaseConfig {

    public static Connection MySqlConfig;

    public static Connection DbConfig() throws SQLException {
        try {
            String url = "jdbc:mysql://localhost:3306/movierental";
            String user = "admin";
            String pass = "root";
            
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            MySqlConfig = DriverManager.getConnection(url, user, pass);
            

        } catch (SQLException e) {
            System.out.println("Failed to Connect" + e.getMessage());
        }
        return MySqlConfig;
    }

}
