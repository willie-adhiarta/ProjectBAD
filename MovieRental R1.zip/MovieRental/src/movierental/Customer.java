/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movierental;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import util.DBHelper;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.xml.bind.DatatypeConverter;
import util.Item;

/**
 *
 * @author tamawangsadinata
 */
public class Customer extends javax.swing.JFrame {

    private DefaultTableModel tableModel;

    /**
     * Creates new form City
     */
    public Customer() {
        initComponents();
        showData();
        setAddress();

        idInput.setEditable(false);
        idInput.setEnabled(false);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);

    }

    public void showData() {
        Object[] row = {"ID", "Name", "Email", "Address", "Active", "Create Date", "Last Update"};
        tableModel = new DefaultTableModel(null, row) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        dataTable.setModel(tableModel);

        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT c.*, a.Address FROM customer c INNER JOIN address a ON c.AddressID = a.ID");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String firstName = rs.getString("First_Name");
                String lastName = rs.getString("Last_Name");
                String address = rs.getString("Address");
                String email = rs.getString("Email");
                String active = rs.getString("Active");
                Date createDate = rs.getDate("Create_Date");
                Date lastUpdate = rs.getDate("Last_Update");

                Object[] data = {id, firstName + " " + lastName, email, address, active, createDate, lastUpdate};

                tableModel.addRow(data);
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void setSelectedData(int id) {
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM customer WHERE ID = " + id);
            if (rs.next()) {
                String firstName = rs.getString("First_Name");
                String lastName = rs.getString("Last_Name");
                int addressId = rs.getInt("AddressID");
                String email = rs.getString("Email");
                String active = rs.getString("Active");

                setSelectedValue(addressCbx, addressId);

                idInput.setText(String.valueOf(id));
                firstNameInput.setText(firstName);
                lastNameInput.setText(lastName);
                emailInput.setText(email);

                boolean isActive = active.equals("Y");
                activeCb.setSelected(isActive);

                updateButton.setEnabled(true);
                deleteButton.setEnabled(true);
                addButton.setEnabled(false);
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public static void setSelectedValue(JComboBox comboBox, int value) {
        Item item;
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            item = (Item) comboBox.getItemAt(i);
            if (item.getId() == value) {
                comboBox.setSelectedIndex(i);
                break;
            }
        }
    }

    public int getLastId() {
        int lastId = 1;
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT MAX(ID) as ID FROM customer");
            if (rs.next()) {
                lastId = rs.getInt("ID") + 1;
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }

        return lastId;
    }

    public void insertData() {
        if (firstNameInput.getText().equals("")
                || lastNameInput.getText().equals("")
                || emailInput.getText().equals("")
                || ((Item) addressCbx.getSelectedItem()).getId() == -1) {
            JOptionPane.showMessageDialog(rootPane, "Please fill all forms");

            return;
        }
        try {
            String query = "insert into customer (ID, AddressID, First_Name, Last_Name, Email, Active, Create_Date) values (?,?,?,?,?,?,?)";
            PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
            p.setInt(1, getLastId());
            p.setInt(2, ((Item) addressCbx.getSelectedItem()).getId());
            p.setString(3, firstNameInput.getText());
            p.setString(4, lastNameInput.getText());
            p.setString(5, emailInput.getText());

            String isActive = activeCb.isSelected() ? "Y" : "N";

            p.setString(6, isActive);

            Date timeNow = new Date(Calendar.getInstance().getTimeInMillis());
            p.setDate(7, timeNow);

            p.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Data Inserted");

            clearForm();
            showData();
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void updateData() {
        if (firstNameInput.getText().equals("")
                || lastNameInput.getText().equals("")
                || emailInput.getText().equals("")
                || ((Item) addressCbx.getSelectedItem()).getId() == -1) {
            JOptionPane.showMessageDialog(rootPane, "Please fill all forms");

            return;
        }
        try {
            int id = Integer.parseInt(idInput.getText());
            String query = "update customer set AddressID=?, First_Name=?, Last_Name=?, Email=?, Active=?, Last_Update=? WHERE ID=" + id;
            PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
            p.setInt(1, ((Item) addressCbx.getSelectedItem()).getId());
            p.setString(2, firstNameInput.getText());
            p.setString(3, lastNameInput.getText());
            p.setString(4, emailInput.getText());

            String isActive = activeCb.isSelected() ? "Y" : "N";
            p.setString(5, isActive);

            Date timeNow = new Date(Calendar.getInstance().getTimeInMillis());
            p.setDate(6, timeNow);

            p.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Data Updated");

            clearForm();
            showData();
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void deleteData() {
        int result = JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to delete this data", "Info", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(idInput.getText());
                String query = "delete from customer WHERE ID=" + id;
                PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
                p.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "Data Deleted");

                clearForm();
                showData();
            } catch (SQLException ex) {
                System.out.println("Error = " + ex.getMessage());
            }
        }
    }

    public void setAddress() {
        Vector model = new Vector();
        model.addElement(new Item(-1, "---- Pilih ----"));

        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM address");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String address = rs.getString("Address");

                model.addElement(new Item(id, address));
            }

            addressCbx.setModel(new DefaultComboBoxModel(model));

        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void clearForm() {
        idInput.setText(null);
        firstNameInput.setText(null);
        lastNameInput.setText(null);
        emailInput.setText(null);
        addressCbx.setSelectedIndex(0);
        activeCb.setSelected(false);

        addButton.setEnabled(true);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        idInput = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        firstNameInput = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        addressCbx = new javax.swing.JComboBox<>();
        lastNameInput = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        emailInput = new javax.swing.JTextField();
        activeCb = new javax.swing.JCheckBox();
        addButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        dataTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Customer");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel1.setText("ID");

        jLabel2.setText("First Name");

        jLabel3.setText("Address");

        jLabel4.setText("Last Name");

        jLabel5.setText("Email");

        activeCb.setText("Active");
        activeCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                activeCbActionPerformed(evt);
            }
        });

        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        updateButton.setText("Update");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        deleteButton.setText("Delete");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lastNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(activeCb)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(emailInput)
                        .addComponent(firstNameInput)
                        .addComponent(idInput, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(addressCbx, 0, 278, Short.MAX_VALUE)))
                .addContainerGap(105, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(idInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(firstNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(lastNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(emailInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(addressCbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(activeCb)
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        dataTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        dataTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dataTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dataTable);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 583, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 182, Short.MAX_VALUE)
                .addGap(19, 19, 19))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void dataTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataTableMouseClicked
        // TODO add your handling code here:
        int selectedRow = dataTable.getSelectedRow();
        int selectedId = (int) dataTable.getModel().getValueAt(selectedRow, 0);

        setSelectedData(selectedId);
    }//GEN-LAST:event_dataTableMouseClicked

    private void activeCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_activeCbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_activeCbActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        insertData();
    }//GEN-LAST:event_addButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        updateData();
    }//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        deleteData();
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        clearForm();
    }//GEN-LAST:event_clearButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Customer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox activeCb;
    private javax.swing.JButton addButton;
    private javax.swing.JComboBox<String> addressCbx;
    private javax.swing.JButton clearButton;
    private javax.swing.JTable dataTable;
    private javax.swing.JButton deleteButton;
    private javax.swing.JTextField emailInput;
    private javax.swing.JTextField firstNameInput;
    private javax.swing.JTextField idInput;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lastNameInput;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables

}
