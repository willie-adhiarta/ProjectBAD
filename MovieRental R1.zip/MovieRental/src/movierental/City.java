/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movierental;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import util.DBHelper;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.xml.bind.DatatypeConverter;
import util.Item;

/**
 *
 * @author tamawangsadinata
 */
public class City extends javax.swing.JFrame {

    private DefaultTableModel tableModel;

    /**
     * Creates new form City
     */
    public City() {
        initComponents();
        showData();
        setCountry();

        idCityInput.setEditable(false);
        idCityInput.setEnabled(false);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);

    }

    public void showData() {
        Object[] row = {"ID", "City Name", "Country", "Last Update"};
        tableModel = new DefaultTableModel(null, row) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        dataCityTable.setModel(tableModel);

        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT s.*, a.Country FROM city s INNER JOIN country a ON s.CountryID = a.ID");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String cityName = rs.getString("City_Name");
                String country = rs.getString("Country");
                Date lastUpdate = rs.getDate("Last_Update");

                Object[] data = {id, cityName, country, lastUpdate};

                tableModel.addRow(data);
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void setSelectedData(int id) {
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM city WHERE ID = " + id);
            if (rs.next()) {
                String city = rs.getString("City_Name");
                int countryId = rs.getInt("CountryID");

                setSelectedValue(idCountryCbx, countryId);

                idCityInput.setText(String.valueOf(id));
                cityNameInput.setText(city);
                updateButton.setEnabled(true);
                deleteButton.setEnabled(true);
                addButton.setEnabled(false);
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public static void setSelectedValue(JComboBox comboBox, int value) {
        Item item;
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            item = (Item) comboBox.getItemAt(i);
            if (item.getId() == value) {
                comboBox.setSelectedIndex(i);
                break;
            }
        }
    }

    public int getLastId() {
        int lastId = 1;
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT MAX(ID) as ID FROM city");
            if (rs.next()) {
                lastId = rs.getInt("ID") + 1;
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }

        return lastId;
    }

    public void insertData() {
        if (cityNameInput.getText().equals("")
                || ((Item) idCountryCbx.getSelectedItem()).getId() == -1) {
            JOptionPane.showMessageDialog(rootPane, "Please fill all forms");

            return;
        }
        try {
            String query = "insert into City values (?,?,?,?)";
            PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
            p.setInt(1, getLastId());
            p.setInt(2, ((Item) idCountryCbx.getSelectedItem()).getId());
            p.setString(3, cityNameInput.getText());
            Date timeNow = new Date(Calendar.getInstance().getTimeInMillis());
            p.setDate(4, timeNow);

            p.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Data Inserted");

            clearForm();
            showData();
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void updateData() {
        if (cityNameInput.getText().equals("")
                || ((Item) idCountryCbx.getSelectedItem()).getId() == -1) {
            JOptionPane.showMessageDialog(rootPane, "Please fill all forms");

            return;
        }
        try {
            int id = Integer.parseInt(idCityInput.getText());
            String query = "update city set City_Name=?,Last_Update=? WHERE ID=" + id;
            PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
            p.setString(1, cityNameInput.getText());
            Date timeNow = new Date(Calendar.getInstance().getTimeInMillis());
            p.setDate(2, timeNow);

            p.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Data Updated");

            clearForm();
            showData();
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void deleteData() {
        int result = JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to delete this data", "Info", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(idCityInput.getText());
                String query = "delete from city WHERE ID=" + id;
                PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
                p.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "Data Deleted");

                clearForm();
                showData();
            } catch (SQLException ex) {
                System.out.println("Error = " + ex.getMessage());
            }
        }
    }

    public void setCountry() {
        Vector model = new Vector();
        model.addElement(new Item(-1, "---- Pilih ----"));

        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Country");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String country = rs.getString("Country");

                model.addElement(new Item(id, country));
            }

            idCountryCbx.setModel(new DefaultComboBoxModel(model));

        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void clearForm() {
        idCityInput.setText(null);
        cityNameInput.setText(null);
        idCountryCbx.setSelectedIndex(0);

        addButton.setEnabled(true);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        idCityInput = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        cityNameInput = new javax.swing.JTextField();
        addButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        idCountryCbx = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        dataCityTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("City");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel1.setText("ID");

        jLabel2.setText("City Name");

        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        updateButton.setText("Update");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        deleteButton.setText("Delete");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        jLabel3.setText("Country ID");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(idCountryCbx, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(addButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(updateButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(clearButton))
                    .addComponent(idCityInput, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cityNameInput))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(idCityInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(idCountryCbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cityNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addButton)
                    .addComponent(updateButton)
                    .addComponent(deleteButton)
                    .addComponent(clearButton))
                .addGap(17, 17, 17))
        );

        dataCityTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        dataCityTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dataCityTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dataCityTable);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void dataCityTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataCityTableMouseClicked
        // TODO add your handling code here:
        int selectedRow = dataCityTable.getSelectedRow();
        int selectedId = (int) dataCityTable.getModel().getValueAt(selectedRow, 0);

        setSelectedData(selectedId);
    }//GEN-LAST:event_dataCityTableMouseClicked

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        clearForm();
    }//GEN-LAST:event_clearButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        deleteData();
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        updateData();
    }//GEN-LAST:event_updateButtonActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        insertData();
    }//GEN-LAST:event_addButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(City.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(City.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(City.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(City.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new City().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JTextField cityNameInput;
    private javax.swing.JButton clearButton;
    private javax.swing.JTable dataCityTable;
    private javax.swing.JButton deleteButton;
    private javax.swing.JTextField idCityInput;
    private javax.swing.JComboBox<String> idCountryCbx;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables

}
