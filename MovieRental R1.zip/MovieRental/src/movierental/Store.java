/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movierental;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import util.DBHelper;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.xml.bind.DatatypeConverter;
import util.Item;

/**
 *
 * @author tamawangsadinata
 */
public class Store extends javax.swing.JFrame {

    private DefaultTableModel tableModel;

    /**
     * Creates new form Store
     */
    public Store() {
        initComponents();
        showData();
        setAddress();

        storeID.setEditable(false);
        storeID.setEnabled(false);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }

    public void showData() {
        Object[] row = {"ID", "Store Name", "Address", "Last Update"};
        tableModel = new DefaultTableModel(null, row) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        dataStoreTable.setModel(tableModel);

        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT s.*, a.Address FROM store s INNER JOIN address a ON s.AddressID = a.ID");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String storeName = rs.getString("Store_Name");
                String address = rs.getString("Address");
                Date lastUpdate = rs.getDate("Last_Update");

                Object[] data = {id, storeName, address, lastUpdate};

                tableModel.addRow(data);
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void setSelectedData(int id) {
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM store WHERE ID = " + id);
            if (rs.next()) {
                String store = rs.getString("Store_Name");
                int addressId = rs.getInt("AddressID");

                setSelectedValue(addressIDCbx, addressId);

                storeID.setText(String.valueOf(id));
                storeName.setText(store);
                updateButton.setEnabled(true);
                deleteButton.setEnabled(true);
                addButton.setEnabled(false);
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public static void setSelectedValue(JComboBox comboBox, int value) {
        Item item;
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            item = (Item) comboBox.getItemAt(i);
            if (item.getId() == value) {
                comboBox.setSelectedIndex(i);
                break;
            }
        }
    }

    public int getLastId() {
        int lastId = 1;
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT MAX(ID) as ID FROM store");
            if (rs.next()) {
                lastId = rs.getInt("ID") + 1;
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }

        return lastId;
    }

    public void insertData() {
        if (storeName.getText().equals("")
                || ((Item) addressIDCbx.getSelectedItem()).getId() == -1) {
            JOptionPane.showMessageDialog(rootPane, "Please fill all forms");

            return;
        }
        try {
            String query = "insert into store values (?,?,?,?)";
            PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
            p.setInt(1, getLastId());
            p.setInt(2, ((Item) addressIDCbx.getSelectedItem()).getId());
            p.setString(3, storeName.getText());
            Date timeNow = new Date(Calendar.getInstance().getTimeInMillis());
            p.setDate(4, timeNow);

            p.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Data Inserted");

            clearForm();
            showData();
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void updateData() {
        if (storeName.getText().equals("")
                || ((Item) addressIDCbx.getSelectedItem()).getId() == -1) {
            JOptionPane.showMessageDialog(rootPane, "Please fill all forms");

            return;
        }
        try {
            int id = Integer.parseInt(storeID.getText());
            String query = "update store set Store_Name=?,Last_Update=? WHERE ID=" + id;
            PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
            p.setString(1, storeName.getText());
            Date timeNow = new Date(Calendar.getInstance().getTimeInMillis());
            p.setDate(2, timeNow);

            p.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Data Updated");

            clearForm();
            showData();
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void deleteData() {
        int result = JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to delete this data", "Info", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(storeID.getText());
                String query = "delete from store WHERE ID=" + id;
                PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
                p.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "Data Deleted");

                clearForm();
                showData();
            } catch (SQLException ex) {
                System.out.println("Error = " + ex.getMessage());
            }
        }
    }

    public void setAddress() {
        Vector model = new Vector();
        model.addElement(new Item(-1, "---- Pilih ----"));

        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Address");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String address = rs.getString("Address");

                model.addElement(new Item(id, address));
            }

            addressIDCbx.setModel(new DefaultComboBoxModel(model));

        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void clearForm() {
        storeID.setText(null);
        storeName.setText(null);
        addressIDCbx.setSelectedIndex(0);

        addButton.setEnabled(true);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        storeID = new javax.swing.JTextField();
        addressIDCbx = new javax.swing.JComboBox<>();
        storeName = new javax.swing.JTextField();
        addButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        dataStoreTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Store");

        jLabel1.setText("ID");

        jLabel2.setText("Address ID");

        jLabel3.setText("Store Name");

        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        updateButton.setText("Update");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        deleteButton.setText("Delete");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(addButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(updateButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deleteButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(clearButton))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(storeName)
                                .addGap(64, 64, 64))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(storeID, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addressIDCbx, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(storeID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(addressIDCbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(storeName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addButton)
                    .addComponent(updateButton)
                    .addComponent(deleteButton)
                    .addComponent(clearButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        dataStoreTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        dataStoreTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dataStoreTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dataStoreTable);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        // TODO add your handling code here:
        insertData();
    }//GEN-LAST:event_addButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        // TODO add your handling code here:
        updateData();
    }//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        // TODO add your handling code here:
        deleteData();
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        // TODO add your handling code here:
        clearForm();
    }//GEN-LAST:event_clearButtonActionPerformed

    private void dataStoreTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataStoreTableMouseClicked
        // TODO add your handling code here:
        int selectedRow = dataStoreTable.getSelectedRow();
        int selectedId = (int) dataStoreTable.getModel().getValueAt(selectedRow, 0);

        setSelectedData(selectedId);
    }//GEN-LAST:event_dataStoreTableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Store.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Store.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Store.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Store.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Store().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JComboBox<String> addressIDCbx;
    private javax.swing.JButton clearButton;
    private javax.swing.JTable dataStoreTable;
    private javax.swing.JButton deleteButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField storeID;
    private javax.swing.JTextField storeName;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables
}
