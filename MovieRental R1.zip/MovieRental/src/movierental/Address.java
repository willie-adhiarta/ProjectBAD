/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movierental;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import util.DBHelper;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.xml.bind.DatatypeConverter;
import util.Item;

/**
 *
 * @author tamawangsadinata
 */
public class Address extends javax.swing.JFrame {

    private DefaultTableModel tableModel;

    /**
     * Creates new form City
     */
    public Address() {
        initComponents();
        showData();
        setCity();

        idInput.setEditable(false);
        idInput.setEnabled(false);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);

    }

    public void showData() {
        Object[] row = {"ID", "Address", "Address2", "City", "District", "Postal Code", "Phone", "Last Update"};
        tableModel = new DefaultTableModel(null, row) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        dataTable.setModel(tableModel);

        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT a.*, c.City_Name FROM address a INNER JOIN city c ON a.CityID = c.ID");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String address = rs.getString("Address");
                String address2 = rs.getString("Address2");
                String cityName = rs.getString("City_Name");
                int district = rs.getInt("District");
                String postalCode = rs.getString("Postal_Code");
                String phone = rs.getString("Phone");
                Date lastUpdate = rs.getDate("Last_Update");

                Object[] data = {id, address, address2, cityName, district, postalCode, phone, lastUpdate};

                tableModel.addRow(data);
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void setSelectedData(int id) {
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM address WHERE ID = " + id);
            if (rs.next()) {
                String address = rs.getString("Address");
                String address2 = rs.getString("Address2");
                int cityId = rs.getInt("CityID");
                int district = rs.getInt("District");
                String postalCode = rs.getString("Postal_Code");
                String phone = rs.getString("Phone");

                setSelectedValue(cityCbx, cityId);

                idInput.setText(String.valueOf(id));
                addressInput.setText(address);
                address2Input.setText(address2);
                districtInput.setText(String.valueOf(district));
                postalCodeInput.setText(postalCode);
                phoneInput.setText(phone);

                updateButton.setEnabled(true);
                deleteButton.setEnabled(true);
                addButton.setEnabled(false);
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public static void setSelectedValue(JComboBox comboBox, int value) {
        Item item;
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            item = (Item) comboBox.getItemAt(i);
            if (item.getId() == value) {
                comboBox.setSelectedIndex(i);
                break;
            }
        }
    }

    public int getLastId() {
        int lastId = 1;
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT MAX(ID) as ID FROM address");
            if (rs.next()) {
                lastId = rs.getInt("ID") + 1;
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }

        return lastId;
    }

    public void insertData() {
        if (addressInput.getText().equals("")
                || districtInput.getText().equals("")
                || postalCodeInput.getText().equals("")
                || phoneInput.getText().equals("")
                || ((Item) cityCbx.getSelectedItem()).getId() == -1) {
            JOptionPane.showMessageDialog(rootPane, "Please fill all forms");

            return;
        }
        
        if(!isNumeric(districtInput.getText())){
            JOptionPane.showMessageDialog(rootPane, "District only allow Numbers");

            return;
        }

        try {
            String query = "insert into address values (?,?,?,?,?,?,?,?)";
            PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
            p.setInt(1, getLastId());
            p.setInt(2, ((Item) cityCbx.getSelectedItem()).getId());
            p.setString(3, addressInput.getText());
            p.setString(4, address2Input.getText());
            p.setInt(5, Integer.parseInt(districtInput.getText()));
            p.setString(6, postalCodeInput.getText());
            p.setString(7, phoneInput.getText());

            Date timeNow = new Date(Calendar.getInstance().getTimeInMillis());
            p.setDate(8, timeNow);

            p.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Data Inserted");

            clearForm();
            showData();
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void updateData() {
        if (addressInput.getText().equals("")
                || districtInput.getText().equals("")
                || postalCodeInput.getText().equals("")
                || phoneInput.getText().equals("")
                || ((Item) cityCbx.getSelectedItem()).getId() == -1) {
            JOptionPane.showMessageDialog(rootPane, "Please fill all forms");

            return;
        }
        
        if(!isNumeric(districtInput.getText())){
            JOptionPane.showMessageDialog(rootPane, "District only allow Numbers");

            return;
        }
        
        try {
            int id = Integer.parseInt(idInput.getText());
            String query = "update address set CityID=?, Address=?, Address2=?, District=?, Postal_Code=?, Phone=?, Last_Update=? WHERE ID=" + id;
            PreparedStatement p = DBHelper.getConnection().prepareStatement(query);

            p.setInt(1, ((Item) cityCbx.getSelectedItem()).getId());
            p.setString(2, addressInput.getText());
            p.setString(3, address2Input.getText());
            p.setInt(4, Integer.parseInt(districtInput.getText()));
            p.setString(5, postalCodeInput.getText());
            p.setString(6, phoneInput.getText());

            Date timeNow = new Date(Calendar.getInstance().getTimeInMillis());
            p.setDate(7, timeNow);

            p.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Data Updated");

            clearForm();
            showData();
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void deleteData() {
        int result = JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to delete this data", "Info", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(idInput.getText());
                String query = "delete from address WHERE ID=" + id;
                PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
                p.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "Data Deleted");

                clearForm();
                showData();
            } catch (SQLException ex) {
                System.out.println("Error = " + ex.getMessage());
            }
        }
    }

    public void setCity() {
        Vector model = new Vector();
        model.addElement(new Item(-1, "---- Pilih ----"));

        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM city");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String address = rs.getString("City_Name");

                model.addElement(new Item(id, address));
            }

            cityCbx.setModel(new DefaultComboBoxModel(model));

        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void clearForm() {
        idInput.setText(null);
        addressInput.setText(null);
        address2Input.setText(null);
        districtInput.setText(null);
        postalCodeInput.setText(null);
        phoneInput.setText(null);
        cityCbx.setSelectedIndex(0);

        addButton.setEnabled(true);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        idInput = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cityCbx = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        districtInput = new javax.swing.JTextField();
        addButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        addressInput = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        address2Input = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        postalCodeInput = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        phoneInput = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        dataTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Address");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel1.setText("ID");

        jLabel2.setText("Address");

        jLabel3.setText("City");

        jLabel5.setText("District");

        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        updateButton.setText("Update");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        deleteButton.setText("Delete");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        addressInput.setColumns(20);
        addressInput.setRows(5);
        jScrollPane2.setViewportView(addressInput);

        address2Input.setColumns(20);
        address2Input.setRows(5);
        jScrollPane3.setViewportView(address2Input);

        jLabel6.setText("Postal Code");

        jLabel7.setText("Phone");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2))
                                .addGap(51, 51, 51)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(idInput, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(76, 76, 76)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(cityCbx, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 298, Short.MAX_VALUE))))
                            .addComponent(jLabel7))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(phoneInput, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(97, 97, 97)
                                        .addComponent(districtInput, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel6)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(postalCodeInput, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(idInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(14, 14, 14)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cityCbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(districtInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6)
                        .addComponent(postalCodeInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(phoneInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        dataTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        dataTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dataTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dataTable);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 583, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void dataTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataTableMouseClicked
        // TODO add your handling code here:
        int selectedRow = dataTable.getSelectedRow();
        int selectedId = (int) dataTable.getModel().getValueAt(selectedRow, 0);

        setSelectedData(selectedId);
    }//GEN-LAST:event_dataTableMouseClicked

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        insertData();
    }//GEN-LAST:event_addButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        updateData();
    }//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        deleteData();
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        clearForm();
    }//GEN-LAST:event_clearButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Address.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Address.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Address.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Address.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Address().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JTextArea address2Input;
    private javax.swing.JTextArea addressInput;
    private javax.swing.JComboBox<String> cityCbx;
    private javax.swing.JButton clearButton;
    private javax.swing.JTable dataTable;
    private javax.swing.JButton deleteButton;
    private javax.swing.JTextField districtInput;
    private javax.swing.JTextField idInput;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField phoneInput;
    private javax.swing.JTextField postalCodeInput;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables

}
