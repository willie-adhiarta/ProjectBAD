/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movierental;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.xml.bind.DatatypeConverter;
import util.DBHelper;
import util.Item;

/**
 *
 * @author mocha
 */
public class Staff extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    private DefaultTableModel tableModel;
    private String resourcePath;
    private File selectedFile;

    public Staff() {
        initComponents();
        showData();
        setAddress();
        setStore();
        resourcePath = getClass().getClassLoader().getResource("resources/").getPath();

        setIcon(null);

        idInput.setEditable(false);
        idInput.setEnabled(false);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
        passwordInfoLabel.setVisible(false);
    }

    public void setIcon(String path) {
        if (path == null) {
            path = resourcePath + "placeholder.png";
        }

        BufferedImage img = null;
        try {
            img = ImageIO.read(new File(path));
            Image dimg = img.getScaledInstance(iconLabel.getWidth(), iconLabel.getHeight(), Image.SCALE_SMOOTH);
            iconLabel.setIcon(new ImageIcon(dimg));
            iconLabel.setText(null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setAddress() {
        Vector model = new Vector();
        model.addElement(new Item(-1, "---- Pilih ----"));

        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM address");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String address = rs.getString("Address");

                model.addElement(new Item(id, address));
            }

            addressCbx.setModel(new DefaultComboBoxModel(model));

        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void setStore() {
        Vector model = new Vector();
        model.addElement(new Item(-1, "---- Pilih ----"));
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM store");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String name = rs.getString("Store_Name");

                model.addElement(new Item(id, name));
            }

            storeCbx.setModel(new DefaultComboBoxModel(model));

        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void showData() {
        Object[] row = {"ID", "Name", "Email", "Store", "Address", "Active", "Picture", "Last Update"};
        tableModel = new DefaultTableModel(null, row) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        dataTable.setModel(tableModel);

        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT s.*, a.Address, st.Store_Name FROM staff s INNER JOIN address a ON s.AddressID = a.ID INNER JOIN store st ON s.StoreId = st.ID");
            while (rs.next()) {
                int id = rs.getInt("ID");
                String firstName = rs.getString("First_Name");
                String lastName = rs.getString("Last_Name");
                String email = rs.getString("Email");
                String store = rs.getString("Store_Name");
                String address = rs.getString("Address");
                String active = rs.getString("Active");
                String picture = rs.getString("PictureUrl");
                Date lastUpdate = rs.getDate("Last_Update");

                Object[] data = {id, firstName + " " + lastName, email, store, address, active, picture, lastUpdate};

                tableModel.addRow(data);
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void setSelectedData(int id) {
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM staff WHERE ID = " + id);
            if (rs.next()) {
                String firstName = rs.getString("First_Name");
                String lastName = rs.getString("Last_Name");
                int addressId = rs.getInt("AddressID");
                int storeId = rs.getInt("StoreID");
                String email = rs.getString("Email");
                String active = rs.getString("Active");
                String picture = rs.getString("PictureURL");

                idInput.setText(String.valueOf(id));
                firstNameInput.setText(firstName);
                lastNameInput.setText(lastName);
                emailInput.setText(email);

                setSelectedValue(addressCbx, addressId);
                setSelectedValue(storeCbx, storeId);

                boolean isActive = active.equals("Y");
                activeCb.setSelected(isActive);

                setIcon(picture);
                updateButton.setEnabled(true);
                deleteButton.setEnabled(true);
                addButton.setEnabled(false);
                passwordInfoLabel.setVisible(true);
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public static void setSelectedValue(JComboBox comboBox, int value) {
        Item item;
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            item = (Item) comboBox.getItemAt(i);
            if (item.getId() == value) {
                comboBox.setSelectedIndex(i);
                break;
            }
        }
    }

    public int getLastId() {
        int lastId = 1;
        try {
            Statement stmt = DBHelper.getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT MAX(ID) as ID FROM staff");
            if (rs.next()) {
                lastId = rs.getInt("ID") + 1;
            }
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }

        return lastId;
    }

    public void insertData() {
        if (firstNameInput.getText().equals("")
                || lastNameInput.getText().equals("")
                || emailInput.getText().equals("")
                || String.valueOf(passwordInput.getPassword()).equals("")
                || ((Item) addressCbx.getSelectedItem()).getId() == -1
                || ((Item) storeCbx.getSelectedItem()).getId() == -1
                || selectedFile == null) {
            JOptionPane.showMessageDialog(rootPane, "Please fill all forms");

            return;
        }
        try {
            String query = "insert into staff values (?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
            p.setInt(1, getLastId());
            p.setInt(2, ((Item) addressCbx.getSelectedItem()).getId());
            p.setInt(3, ((Item) storeCbx.getSelectedItem()).getId());
            p.setString(4, firstNameInput.getText());
            p.setString(5, lastNameInput.getText());
            p.setString(6, emailInput.getText());

            String isActive = activeCb.isSelected() ? "Y" : "N";

            p.setString(7, isActive);
            p.setString(8, getMD5(String.valueOf(passwordInput.getPassword())));
            Date timeNow = new Date(Calendar.getInstance().getTimeInMillis());
            p.setDate(9, timeNow);

            p.setString(10, selectedFile.getAbsolutePath());

            p.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Data Inserted");

            clearForm();
            showData();
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void updateData() {
        if (firstNameInput.getText().equals("")
                || lastNameInput.getText().equals("")
                || emailInput.getText().equals("")
                || ((Item) addressCbx.getSelectedItem()).getId() == -1
                || ((Item) storeCbx.getSelectedItem()).getId() == -1) {
            JOptionPane.showMessageDialog(rootPane, "Please fill all forms");

            return;
        }

        try {
            int id = Integer.parseInt(idInput.getText());
            String query = "update staff set AddressID=?, StoreID=?, First_Name=?, Last_Name=?, Email=?, Active=?, Last_Update=?";

            if (selectedFile != null) {
                query += ", PictureURL=?";
            }
            if (!String.valueOf(passwordInput.getPassword()).equals("")) {
                query += ", Password=?";
            }
            query += " WHERE ID=" + id;

            PreparedStatement p = DBHelper.getConnection().prepareStatement(query);

            p.setInt(1, ((Item) addressCbx.getSelectedItem()).getId());
            p.setInt(2, ((Item) storeCbx.getSelectedItem()).getId());
            p.setString(3, firstNameInput.getText());
            p.setString(4, lastNameInput.getText());
            p.setString(5, emailInput.getText());

            String isActive = activeCb.isSelected() ? "Y" : "N";
            p.setString(6, isActive);

            Date timeNow = new Date(Calendar.getInstance().getTimeInMillis());
            p.setDate(7, timeNow);

            int paramIndex = 8;

            if (selectedFile != null) {
                p.setString(paramIndex, selectedFile.getAbsolutePath());
                paramIndex = 9;
            }

            if (!String.valueOf(passwordInput.getPassword()).equals("")) {
                p.setString(paramIndex, getMD5(String.valueOf(passwordInput.getPassword())));
            }
            p.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Data Updated");

            clearForm();
            showData();
        } catch (SQLException ex) {
            System.out.println("Error = " + ex.getMessage());
        }
    }

    public void deleteData() {
        int result = JOptionPane.showConfirmDialog(rootPane, "Are you sure you want to delete this data", "Info", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(idInput.getText());
                String query = "delete from staff WHERE ID=" + id;
                PreparedStatement p = DBHelper.getConnection().prepareStatement(query);
                p.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "Data Deleted");

                clearForm();
                showData();
            } catch (SQLException ex) {
                System.out.println("Error = " + ex.getMessage());
            }
        }
    }

    public void clearForm() {
        idInput.setText(null);
        firstNameInput.setText(null);
        lastNameInput.setText(null);
        emailInput.setText(null);
        passwordInput.setText(null);
        addressCbx.setSelectedIndex(0);
        storeCbx.setSelectedIndex(0);
        activeCb.setSelected(false);
        selectedFile = null;
        setIcon(null);

        addButton.setEnabled(true);
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
        passwordInfoLabel.setVisible(false);

    }

    public void showUploadDialog() {
        FileFilter imageFilter = new FileNameExtensionFilter(
                "Image files", ImageIO.getReaderFileSuffixes());

        JFileChooser filechooser = new JFileChooser();
        filechooser.setFileFilter(imageFilter);
        filechooser.setDialogTitle("Choose Your File");
        filechooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        // below code selects the file 
        int returnval = filechooser.showOpenDialog(this);
        if (returnval == JFileChooser.APPROVE_OPTION) {
            selectedFile = filechooser.getSelectedFile();

            BufferedImage bi;
            try {
                bi = ImageIO.read(selectedFile);
                String extension = getFormat(selectedFile.getName());
                Image img = bi.getScaledInstance(iconLabel.getWidth(), iconLabel.getHeight(), Image.SCALE_SMOOTH);
                iconLabel.setIcon(new ImageIcon(img));

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String getFormat(String ImageName) {

        return (ImageName.substring(ImageName.indexOf('.') + 1, ImageName.length()));
    }

    public static String getMD5(String password) {
        String hash = "";

        try {
            MessageDigest md;

            md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes());
            byte[] digest = md.digest();
            hash = DatatypeConverter
                    .printHexBinary(digest).toUpperCase();
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
        }

        return hash;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        idInput = new javax.swing.JTextField();
        firstNameInput = new javax.swing.JTextField();
        addButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        updateButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        lastNameInput = new javax.swing.JTextField();
        emailInput = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        passwordInput = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        addressCbx = new javax.swing.JComboBox<>();
        storeCbx = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        activeCb = new javax.swing.JCheckBox();
        jLabel9 = new javax.swing.JLabel();
        iconLabel = new javax.swing.JLabel();
        uploadButton = new javax.swing.JButton();
        passwordInfoLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        dataTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Staff");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel1.setText("ID");

        jLabel2.setText("First Name");

        idInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idInputActionPerformed(evt);
            }
        });

        firstNameInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                firstNameInputActionPerformed(evt);
            }
        });

        addButton.setText("Add");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        deleteButton.setText("Delete");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        updateButton.setText("Update");
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        jLabel3.setText("Last Name");

        lastNameInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lastNameInputActionPerformed(evt);
            }
        });

        emailInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailInputActionPerformed(evt);
            }
        });

        jLabel4.setText("Email");

        jLabel5.setText("Password");

        jLabel6.setText("Address");

        jLabel7.setText("Store");

        activeCb.setText("Is Active");
        activeCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                activeCbActionPerformed(evt);
            }
        });

        jLabel9.setText("Picture");

        uploadButton.setText("Browse");
        uploadButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadButtonActionPerformed(evt);
            }
        });

        passwordInfoLabel.setText("Leave blank if you don't want to change it");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(activeCb)
                        .addGap(222, 222, 222))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lastNameInput)
                            .addComponent(firstNameInput)
                            .addComponent(passwordInput)
                            .addComponent(emailInput)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(passwordInfoLabel)
                                    .addComponent(idInput, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(31, 31, 31)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addGap(56, 56, 56)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(addressCbx, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(storeCbx, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(63, 63, 63)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(uploadButton, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(iconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(72, 72, 72))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(201, 201, 201)
                .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(idInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(addressCbx, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(firstNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7)
                        .addComponent(storeCbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(lastNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(emailInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(passwordInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(passwordInfoLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(activeCb))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(iconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(uploadButton)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );

        dataTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        dataTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dataTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dataTable);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addGap(0, 19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        getAccessibleContext().setAccessibleName("Staff");
        getAccessibleContext().setAccessibleDescription("");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void dataTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dataTableMouseClicked
        int selectedRow = dataTable.getSelectedRow();
        int selectedId = (int) dataTable.getModel().getValueAt(selectedRow, 0);

        setSelectedData(selectedId);
    }//GEN-LAST:event_dataTableMouseClicked

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        clearForm();
    }//GEN-LAST:event_clearButtonActionPerformed

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        updateData();
    }//GEN-LAST:event_updateButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        deleteData();
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        insertData();
    }//GEN-LAST:event_addButtonActionPerformed

    private void firstNameInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_firstNameInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_firstNameInputActionPerformed

    private void idInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idInputActionPerformed

    private void lastNameInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastNameInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lastNameInputActionPerformed

    private void emailInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailInputActionPerformed

    private void activeCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_activeCbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_activeCbActionPerformed

    private void uploadButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uploadButtonActionPerformed
        showUploadDialog();
    }//GEN-LAST:event_uploadButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Staff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Staff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Staff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Staff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Staff().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox activeCb;
    private javax.swing.JButton addButton;
    private javax.swing.JComboBox<String> addressCbx;
    private javax.swing.JButton clearButton;
    private javax.swing.JTable dataTable;
    private javax.swing.JButton deleteButton;
    private javax.swing.JTextField emailInput;
    private javax.swing.JTextField firstNameInput;
    private javax.swing.JLabel iconLabel;
    private javax.swing.JTextField idInput;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lastNameInput;
    private javax.swing.JLabel passwordInfoLabel;
    private javax.swing.JPasswordField passwordInput;
    private javax.swing.JComboBox<String> storeCbx;
    private javax.swing.JButton updateButton;
    private javax.swing.JButton uploadButton;
    // End of variables declaration//GEN-END:variables
}
