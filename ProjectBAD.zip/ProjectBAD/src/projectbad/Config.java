/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectbad;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hp
 */
public class Config {
    
    private static Connection connection;
    
    public static Connection dbConn() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/movierental";
            String user = "root";
            String password = "password";
            connection = DriverManager.getConnection(url, user, password);
        }
        catch (SQLException ex) {
            System.out.println("Koneksi DB Gagal! " + ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Config.class.getName()).log(Level.SEVERE, null, ex);
        }
        return connection;
    }
    
}
